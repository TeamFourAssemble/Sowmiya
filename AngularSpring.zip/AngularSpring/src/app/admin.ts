export interface Admin {

    name: string;
    phone:string;
    email: string;
    password: string;
}
