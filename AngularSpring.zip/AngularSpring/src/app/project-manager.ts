export interface ProjectManager {
    id?:number;
    name:string;
    email:string;
    password:string;
}
