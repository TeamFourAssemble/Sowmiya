import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-timelines',
  templateUrl: './project-timelines.component.html',
  styleUrls: ['./project-timelines.component.css']
})
export class ProjectTimelinesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
