import { Component } from '@angular/core';

@Component({
  selector: 'app-thome',
  templateUrl: './thome.component.html',
  styleUrl: './thome.component.css'
})
export class ThomeComponent {

}
