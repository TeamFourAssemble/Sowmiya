export interface Project {

    title:string;
    description:string;
}
