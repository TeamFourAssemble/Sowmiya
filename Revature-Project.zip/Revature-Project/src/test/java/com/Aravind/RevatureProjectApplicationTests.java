package com.Aravind;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RevatureProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
